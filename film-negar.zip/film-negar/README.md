# فیلم نگار — راهنمای انتشار روی Vercel

## ۱. کلید TMDB
در themoviedb.org وارد حساب شوید، از Settings ← API یکی از این دو را بردارید: «API Key» یا «API Read Access Token». کلید را جایی عمومی نفرستید.

## ۲. انتشار (روش بدون خط فرمان)
1. در github.com یک مخزن (Repository) خصوصی بسازید و محتویات همین پوشه (`index.html` و پوشهٔ `api`) را در آن آپلود کنید.
2. در vercel.com با حساب GitHub وارد شوید ← Add New ← Project ← مخزن را Import کنید.
3. قبل از Deploy، بخش Environment Variables را باز کنید:
   Name: `TMDB_API_KEY` ، Value: کلید شما ← Add
4. Deploy را بزنید. بعد از چند ثانیه آدرس اپ آماده است.

اگر بعداً کلید را عوض کردید: Project ← Settings ← Environment Variables، سپس یک Redeploy بزنید.

## روش خط فرمان
```
cd film-negar
npx vercel
npx vercel env add TMDB_API_KEY
npx vercel --prod
```

## نکته‌ها
- اطلاعات لیست‌ها هنوز در مرورگر هر کاربر ذخیره می‌شود. برای حساب کاربری و دوستان واقعی مرحلهٔ بعدی (دیتابیس) لازم است.
- این محصول از API شرکت TMDB استفاده می‌کند ولی توسط TMDB تأیید یا پشتیبانی نمی‌شود (شرط استفادهٔ رایگان از API).
